from django.apps import AppConfig

class PeluqueriaConfig(AppConfig):
    name = 'peluqueria'
